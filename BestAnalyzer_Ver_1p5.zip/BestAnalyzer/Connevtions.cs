﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class Connevtions : Form
    {
        connections2 connection2_temp;
        public int baud_rate_Selected = 0;
        public string comport_selected = "";

        int[] baudrates = { 110, 150, 300, 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600 };
        public Connevtions()
        {
            InitializeComponent();
            comboBox1.Items.Clear();
            string[] portnames = SerialPort.GetPortNames();
            foreach (string port in portnames)
            {
                comboBox1.Items.Add(port);
            }
            
        }

        private void Connevtions_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] portnames = SerialPort.GetPortNames();
            foreach (string port in portnames)
            {
                comboBox1.Items.Add(port);
            }
        }

        public void updatecomports(connections2 correction2_form)
        {
            connection2_temp =  correction2_form;
            comboBox1.Items.Clear();
            string[] portnames = SerialPort.GetPortNames();
            foreach (string port in portnames)
            {
                comboBox1.Items.Add(port);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //com port
            label6.Text = comboBox1.Text;
            comport_selected = label6.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // baud rate
            label7.Text = comboBox2.Text;
            baud_rate_Selected = baudrates[comboBox2.SelectedIndex];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SerialPort searial_read;
                searial_read = new SerialPort(label6.Text, baud_rate_Selected);
                searial_read.Open();
                label8.Text = "Yes";
                searial_read.Close();
                connection2_temp.necessorydata(baud_rate_Selected, label6.Text);
                this.Hide();
            }
            catch(Exception )
            {
                label8.Text = "No";
            }
        }

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            label7.Text = comboBox2.Text;
            baud_rate_Selected = Int32.Parse(comboBox2.Text);
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            label6.Text = comboBox1.Text;
            comport_selected = label6.Text;
        }
    }
}
