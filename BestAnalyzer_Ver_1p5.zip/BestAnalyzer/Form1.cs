﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BestAnalyzer
{

    
    public partial class Form1 : Form
    {
        Connevtions correction_form = new Connevtions();
        storedata1 stordata1_form = new storedata1();
        connections2 connection2_form = new connections2();
        helpwindow1 helpwindow1_form = new helpwindow1();
        Message1 message1_form = new Message1();
        welcome welcome_form = new welcome();
        private bool flag = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

       

        public Form1()
        {
            InitializeComponent();

            correction_form.TopLevel = false;
            panel3.Controls.Add(correction_form);
            correction_form.Visible = false;

            stordata1_form.TopLevel = false;
            panel3.Controls.Add(stordata1_form);
            stordata1_form.Visible = false;
            
            connection2_form.TopLevel = false;
            panel3.Controls.Add(connection2_form);
            connection2_form.Visible = false;

            message1_form.TopLevel = false;
            panel3.Controls.Add(message1_form);
            message1_form.Visible = false;

            helpwindow1_form.TopLevel = false;
            panel3.Controls.Add(helpwindow1_form);
            helpwindow1_form.Visible = false;

            welcome_form.TopLevel = false;
            panel3.Controls.Add(welcome_form);
            welcome_form.Visible = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Location = new System.Drawing.Point(0, button2.Location.Y);
            welcome_form.Visible = false;
            label2.Text = "Stored Data";
            stordata1_form.Visible = true;
            correction_form.Visible = false;
            message1_form.Visible = false;
            helpwindow1_form.Visible = false;


        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Location = new System.Drawing.Point(0, button1.Location.Y);
            label2.Text = "Connections";
            welcome_form.Visible = false;
            stordata1_form.Visible = false;
            message1_form.Visible = false;
            helpwindow1_form.Visible = false;
            correction_form.updatecomports(connection2_form);
            correction_form.Visible = true;
            connection2_form.Visible = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel2.Location = new System.Drawing.Point(0, button3.Location.Y);
            label2.Text = "Messages";
            welcome_form.Visible = false;
            stordata1_form.Visible = false;
            message1_form.Visible = false;
            helpwindow1_form.Visible = false;
            message1_form.Visible = true;
            stordata1_form.Visible = false;
            connection2_form.Visible = false;
            correction_form.Visible = false;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Location = new System.Drawing.Point(0, button4.Location.Y);
            label2.Text = "Help";
            welcome_form.Visible = false;
            stordata1_form.Visible = false;
            connection2_form.Visible = false;
            correction_form.Visible = false;
            message1_form.Visible = false;
            helpwindow1_form.Visible = false;
            helpwindow1_form.Visible = true;


        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                connection2_form.stop_plot();
                connection2_form.close_port();
            }
            catch(Exception)
            {

            }
            this.Close();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            flag = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            flag = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (flag)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
