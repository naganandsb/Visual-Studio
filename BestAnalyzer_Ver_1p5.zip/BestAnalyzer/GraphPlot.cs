﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BestAnalyzer
{
    public partial class GraphPlot : Form
    {
        int clear_count = 0;
        private bool flag = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;
        private delegate void SetTextDeleg(float x,float y);
        public string Header_real;
        public int Xmsg_real = 0;
        public int Ymsg_real = 0;
        public int Style_real =0;
        public int Color_real =0;
        public int Back_color_real =0;
        public int Plot_axies_real =0;
        public string Header_msg = "";
        public char SeperatedBy_msg;
        public int numberOfFields_msg = 0;
        public GraphPlot()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void updateplot(string header,float[] X,float[] Y , Int64 len,int style,int type,int color,int back_color, int plot_axies)
        {

            label1.Text = header;
            switch (style)
            {
                case 0:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                    break;
                case 1:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
                    break;
                case 2:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bubble;
                    break;
                case 3:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
                    break;
                case 4:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
                    break;
                case 5:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                    break;
                case 6:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
                    break;
                case 7:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Polar;
                    break;
                case 8:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Stock;
                    break;
                case 9:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid;
                    break;
                case 10:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.BoxPlot;
                    break;


            }
            switch (back_color)
            { 
                case 0:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Black;
                    break;
                case 1:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Green;
                    break;
                case 2:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Red;
                    break;
                case 3:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Yellow;
                    break;
                case 4:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Cyan;
                    break;
                case 5:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Magenta;
                    break;
                case 6:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Blue;
                    break;
                case 7:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.White;
                    break;


            }
            switch (color)
            {
                case 0:
                    chart1.Series["Series1"].Color = Color.Black;
                    button2.ForeColor = Color.Black;
                    break;
                case 1:
                    chart1.Series["Series1"].Color = Color.Green;
                    button2.ForeColor = Color.Green;
                    break;
                case 2:
                    chart1.Series["Series1"].Color = Color.Red;
                    button2.ForeColor = Color.Red;
                    break;
                case 3:
                    chart1.Series["Series1"].Color = Color.Yellow;
                    button2.ForeColor = Color.Yellow;
                    break;
                case 4:
                    chart1.Series["Series1"].Color = Color.Cyan;
                    button2.ForeColor = Color.Cyan;
                    break;
                case 5:
                    chart1.Series["Series1"].Color = Color.Magenta;
                    button2.ForeColor = Color.Magenta;
                    break;
                case 6:
                    chart1.Series["Series1"].Color = Color.Blue;
                    button2.ForeColor = Color.Blue;
                    break;
                case 7:
                    chart1.Series["Series1"].Color = Color.White;
                    button2.ForeColor = Color.White;
                    break;


            }
            float temp = 0;
            switch (type)
            {
                case 0:
                    break;
                case 1:
                    
                    break;
                case 2:
                    double tmp = 0;
                    for (Int64 i = 0; i < len; i++)
                    {

                        tmp += Y[i];
                    }
                    temp =(float) tmp / len;
                    for (Int64 i = 0; i < len; i++)
                    {

                         Y[i] = Y[i] - temp;
                    }
                    break;
                case 3:
                    temp = Y.Max();
                    for (Int64 i = 0; i < len; i++)
                    {
                        Y[i] = Y[i] - temp;
                    }
                    break;
                case 4:
                    temp = Y.Min();
                    for (Int64 i = 0; i < len; i++)
                    {
                        Y[i] = Y[i] - temp;
                    }
                    break;
                case 6:
                    
                    for (Int64 i = 0; i < len-1; i++)
                    {

                        Y[i] = Math.Abs(Y[i+1]- Y[i] );
                    }
                    break;
                case 7:
                    temp = Y.Max();
                    for (Int64 i = 0; i < len; i++)
                    {
                        if (Y[i] != temp)
                        {
                            Y[i] = 0;
                        }
                    }
                    break;
                case 8:
                    temp = Y.Min();
                    for (Int64 i = 0; i < len; i++)
                    {
                        if(Y[i] != temp)
                        {
                            Y[i] = 0;
                        }
                    }
                    break;
                case 9:
                    double tmp_dbl = 0;
                    for (Int64 i = 0; i < len; i++)
                    {
                        tmp_dbl += (Y[i] * Y[i]);
                    }
                    tmp_dbl = tmp_dbl / len;
                    tmp_dbl = Math.Sqrt(tmp_dbl);
                    Y[0] = float.Parse(tmp_dbl.ToString());
                    for (Int64 i = 0; i < len; i++)
                    {
                        if(Y[i] == tmp_dbl)
                        {
                            continue;
                        }
                        Y[i] = float.Parse(tmp_dbl.ToString());
                    }
                    break;
                case 11:

                    for (Int64 i = 0; i < len; i++)
                    {
                        Y[i] = Math.Abs(Y[i]);
                    }
                    break;
            }
            
            if(plot_axies == 0)
            {
                
                for (Int64 i = 0; i < len; i++)
                {
                    chart1.Series["Series1"].Points.AddXY(X[i], Y[i]);
                }
            }
            else if (plot_axies == 1)
            {
                for (Int64 i = 0; i < len; i++)
                {
                    chart1.Series["Series1"].Points.AddXY(X[i], i);
                }
            }
            else if (plot_axies == 2)
            {
                for (Int64 i = 0; i < len; i++)
                {
                    chart1.Series["Series1"].Points.AddXY(i, Y[i]);
                }
            }






        }

        public void realextract(string ln)
        {
            
            float X = 0;
            float Y = 0;
            
            if(ln.Contains(Header_msg))
            {
                string[] spln = ln.Split(SeperatedBy_msg);
                try
                {
                    X = float.Parse(spln[Xmsg_real]);
                }
                catch(Exception)
                {
                    X = 0;
                }
                try
                {
                    Y = float.Parse(spln[Ymsg_real]);
                }
                catch (Exception)
                {
                    Y = 0;
                }
                try
                {
                    this.BeginInvoke(new SetTextDeleg(updaterealplot), new object[] { X, Y });

                }
                catch(Exception)
                {

                }
                //updaterealplot(X, Y);
            }
            
           

            
        }

        private void si_DataReceived(float X, float Y)
        {
            if(clear_count == 100)
            {
                chart1.Series["Series1"].Points.Clear();
            }
            if (Plot_axies_real == 0)
            {

                chart1.Series["Series1"].Points.AddXY(X, Y);
            }

            else if (Plot_axies_real == 1)
            {
                chart1.Series["Series1"].Points.AddXY(X, 0);
            }
            else if (Plot_axies_real == 2)
            {

                chart1.Series["Series1"].Points.AddY(Y);
            }
            clear_count++;
        }
        public void updaterealplot(float X, float Y)
        {

            label1.Text = Header_real;
            switch (Style_real)
            {
                case 0:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                    break;
                case 1:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
                    break;
                case 2:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bubble;
                    break;
                case 3:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
                    break;
                case 4:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
                    break;
                case 5:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                    break;
                case 6:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
                    break;
                case 7:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Polar;
                    break;
                case 8:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Stock;
                    break;
                case 9:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid;
                    break;
                case 10:
                    chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.BoxPlot;
                    break;


            }
            switch (Back_color_real)
            {
                case 0:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Black;
                    break;
                case 1:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Green;
                    break;
                case 2:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Red;
                    break;
                case 3:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Yellow;
                    break;
                case 4:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Cyan;
                    break;
                case 5:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Magenta;
                    break;
                case 6:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.Blue;
                    break;
                case 7:
                    chart1.ChartAreas["ChartArea1"].BackColor = Color.White;
                    break;


            }
            switch (Color_real)
            {
                case 0:
                    chart1.Series["Series1"].Color = Color.Black;
                    button2.ForeColor = Color.Black;
                    break;
                case 1:
                    chart1.Series["Series1"].Color = Color.Green;
                    button2.ForeColor = Color.Green;
                    break;
                case 2:
                    chart1.Series["Series1"].Color = Color.Red;
                    button2.ForeColor = Color.Red;
                    break;
                case 3:
                    chart1.Series["Series1"].Color = Color.Yellow;
                    button2.ForeColor = Color.Yellow;
                    break;
                case 4:
                    chart1.Series["Series1"].Color = Color.Cyan;
                    button2.ForeColor = Color.Cyan;
                    break;
                case 5:
                    chart1.Series["Series1"].Color = Color.Magenta;
                    button2.ForeColor = Color.Magenta;
                    break;
                case 6:
                    chart1.Series["Series1"].Color = Color.Blue;
                    button2.ForeColor = Color.Blue;
                    break;
                case 7:
                    chart1.Series["Series1"].Color = Color.White;
                    button2.ForeColor = Color.White;
                    break;


            }

            si_DataReceived(X,Y);
            
            






        }
        private void GraphPlot_Load(object sender, EventArgs e)
        {

        }

        private void GraphPlot_MouseDown(object sender, MouseEventArgs e)
        {
            flag = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void GraphPlot_MouseMove(object sender, MouseEventArgs e)
        {
            if (flag)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void GraphPlot_MouseUp(object sender, MouseEventArgs e)
        {
            flag = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(saveFileDialog1.ShowDialog() == DialogResult.OK )
            {
                string path = saveFileDialog1.FileName;
                if(path.Contains('.'))
                {
                    chart1.SaveImage(path, ImageFormat.Png);
                }
                else
                {
                    path += ".png";
                    chart1.SaveImage(path, ImageFormat.Png);
                }
                
            }
            
        }
    }
}
