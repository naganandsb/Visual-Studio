﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class Message1 : Form
    {
        ComboBox[] field_type = new ComboBox[25];
        TextBox[] field_names = new TextBox[25];

        public Message1()
        {
            int countLocation = 0;
            InitializeComponent();
            for(int i =0;i < 25;i++)
            {
                if (countLocation == 9)
                {
                    countLocation = 0;

                }
                field_type[i] = new ComboBox();
                field_type[i].Visible = false;
                field_type[i].Items.Add("bool");
                field_type[i].Items.Add("char");
                field_type[i].Items.Add("int");
                field_type[i].Items.Add("float");
                field_type[i].Items.Add("double");
                field_type[i].Items.Add("string");
                field_type[i].DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
                field_type[i].Location = new System.Drawing.Point(116, 32+(countLocation *27));
                field_type[i].Size = new System.Drawing.Size(50, 21);

                field_names[i] = new TextBox();
                field_names[i].Visible = false;
                field_names[i].Location = new System.Drawing.Point(9, 32 + (countLocation * 27));
                field_names[i].Size = new System.Drawing.Size(50, 21);
                countLocation++;
                
                if (i > -1 && i < 9)
                {
                    panel1.Controls.Add(field_type[i]);
                    panel1.Controls.Add(field_names[i]);


                }
                if (i > 8 && i < 18)
                {
                    panel2.Controls.Add(field_type[i]);
                    panel2.Controls.Add(field_names[i]);

                }
                if (i > 17)
                {
                    panel3.Controls.Add(field_type[i]);
                    panel3.Controls.Add(field_names[i]);

                }

               


            }

           

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i= 0;i <= comboBox1.SelectedIndex;i++)
            {
                field_names[i].Visible = true;

                field_type[i].Visible = true;

            }
            if (comboBox1.SelectedIndex > -1)
            {
                panel1.Visible = true;


            }
            else
            {
                panel1.Visible = false;
            }
            if (comboBox1.SelectedIndex > 8)
            {
                panel2.Visible = true;
            }
            else
            {
                panel2.Visible = false;
            }
            if (comboBox1.SelectedIndex > 17)
            {
                panel3.Visible = true;
            }
            else
            {
                panel3.Visible = false;
            }
        }

        private void Message1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if(! Directory.Exists("C:\\BestExtractor\\"))
            {
                Directory.CreateDirectory("C:\\BestExtractor\\");
            }
            if (textBox1.Text == "")
            {
                label12.Text = "Error: Please Enter Message Name";
                return;
            }
            if (textBox2.Text == "")
            {
                label12.Text = "Error: Please Enter Header";
                return;
            }
            if (textBox3.Text == "")
            {
                label12.Text = "Error: Please Enter seperation char or string";
                return;
            }
            if (comboBox1.Text == "")
            {
                label12.Text = "Error: number of field should not be zero";
                return;
            }
            string full_info = "";
            string full_path = "C:\\BestExtractor\\" + textBox1.Text + ".txt";

            full_info += "File_name:"+textBox1.Text +":\r\nHeader:"+ textBox2.Text +":\r\nseperated_by:"+textBox3.Text+":\r\n" ;
            full_info += "Number_of_fields:" + comboBox1.Text + ":\r\nrepetative:"+checkBox1.Checked+"\r\n";

            int number_of_feilds = Int16.Parse(comboBox1.Text);

            for(int i=0;i < number_of_feilds;i++ )
            {
                if(field_names[i].Text =="")
                {
                    label12.Text = "Error: field name should not be  empty";
                    return;
                }
                if (field_type[i].Text == "")
                {
                    label12.Text = "Error: Please select field type";
                    return;
                }

                full_info += "field:\t" + field_names[i].Text + ":\t" + field_type[i].Text + ":\r\n";
            }


            File.WriteAllText(full_path, full_info);

            this.Hide();
        }
    }
}
