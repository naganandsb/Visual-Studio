﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    class Sendbutton : Button
    {
        protected override void OnPaint(PaintEventArgs pevent)
        {
            int midx = ClientRectangle.X + (ClientRectangle.Width / 2);
            int midy = ClientRectangle.Y + (ClientRectangle.Height / 2);
            Point[] pt =
            {


                new Point(ClientRectangle.X +2,ClientRectangle.Y+1),
                new Point(ClientRectangle.X+ClientRectangle.Width-2,midy),
                new Point(ClientRectangle.X+2,ClientRectangle.Y+ClientRectangle.Height-1),
                new Point(ClientRectangle.X+2,ClientRectangle.Y+1)

            };

            GraphicsPath polygon_path = new GraphicsPath(FillMode.Winding);

            polygon_path.AddPolygon(pt);

            Region polygon_region = new Region(polygon_path);

            this.Region = polygon_region;
            base.OnPaint(pevent);
        }
    }
}
