﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class connectiongpoption : Form
    {
        connections2 con2_form;

        int plot_axies = 0;
        int plot_type = 0;
        int plot_style = 0;
        int plot_color = 0;
        int back_color = 0;
        int xmessage = 0;
        int ymessage = 0;
        char seperated_by;
        string head_op = "";
        int num_of_flds = 0;
        public connectiongpoption()
        {
            InitializeComponent();
        }

        public void setformdata(connections2 stored1_form_temp, string[] paras_to_plot,int loop_numbr_max,char sepby,string header,int numofflds)
        {
            con2_form = stored1_form_temp;
            seperated_by = sepby;
            head_op = header;
            num_of_flds = numofflds;

            for (int indx = 0; indx < loop_numbr_max; indx++)
            {

                comboBox1.Items.Add(paras_to_plot[indx]);
                comboBox2.Items.Add(paras_to_plot[indx]);

            }
        }

        private void sendbutton1_Click(object sender, EventArgs e)
        {
            
            plot_style = comboBox4.SelectedIndex;
            plot_color = comboBox3.SelectedIndex;
            back_color = comboBox6.SelectedIndex;
            plot_axies = comboBox7.SelectedIndex;

            xmessage = comboBox1.SelectedIndex;
            ymessage = comboBox2.SelectedIndex;



            con2_form.call_plot(plot_color, plot_style, plot_type, xmessage, ymessage, back_color, plot_axies, seperated_by,head_op,num_of_flds);


        }
    }
}
