﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class connections2 : Form
    {
        int real_time_plot_count = 0;
        string glob_var = "";
        int enable_log = 0;
        int loop_numbr_max = 0;
        GraphPlot[] arraygpplots = new GraphPlot[100];
        SerialPort searial_read;
        int baud_rate = 0;
        string com_port = "";
        bool _continue =  false;
        bool shtead_control_flag = true;
        string[] paras = new string[25];
        connectiongpoption gpop_form = new connectiongpoption();
        plotconnection plotconnection_form = new plotconnection();
        

        private delegate void SetTextDeleg(string text);

        
        public connections2()
        {
            InitializeComponent();
            plotconnection_form.Visible = false;
            plotconnection_form.TopLevel = false;
            panel3.Controls.Add(plotconnection_form);
            gpop_form.Visible = false;
            gpop_form.TopLevel = false;
            panel3.Controls.Add(gpop_form);

        }

        
        private void connections2_Load(object sender, EventArgs e)
        {

        }
        public void necessorydata(int baudrate,string comport)
        {
            com_port = comport;

            baud_rate = baudrate;

            
            searial_read = new SerialPort(com_port, baud_rate);
            //searial_read.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived);
            searial_read.Open();
            Thread readThread = new Thread(Read);
            readThread.IsBackground = true;
            readThread.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gpop_form.Visible = false;
            plotconnection_form.Visible = false;
            textBox3.Visible = true;
            _continue = true;
            
            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if(searial_read.IsOpen == false)
            {
                return;
            }    
            searial_read.Write(textBox1.Text);
        }

        private void startstop1_Click(object sender, EventArgs e)
        {
            if(textBox2.Text == "" || "Please Enter the File name here" == textBox2.Text)
            {
                textBox2.Text = "Please Enter the File name here";
                return;
            }
            
            
            

            //File.Create(textBox2.Text);
            startstop2.Enabled = true;
            startstop1.Enabled = false;
            label2.Enabled = false;
            pictureBox2.Enabled = false;
            textBox2.Enabled = false;
            enable_log = 1;

        }

        private void startstop2_Click(object sender, EventArgs e)
        {
            startstop2.Enabled = false;
            startstop1.Enabled = true;
            label2.Enabled = true;
            pictureBox2.Enabled = true;
            textBox2.Enabled = true;
            enable_log = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            textBox2.Text = saveFileDialog1.FileName;
        }


        void sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                Thread.Sleep(100);
                
                string data = searial_read.ReadLine();
                // Invokes the delegate on the UI thread, and sends the data that was received to the invoked method.  
                // ---- The "si_DataReceived" method will be executed on the UI thread which allows populating of the textbox.  
                this.BeginInvoke(new SetTextDeleg(si_DataReceived), new object[] { data });


            }
            catch(Exception)
            {

            }
        }

        private void si_DataReceived(string data) { textBox3.Text += data.Trim()+"\r\n"; textBox3.SelectionStart = textBox3.TextLength;
            textBox3.ScrollToCaret();
        }
        public void close_port()
        {
            searial_read.Close();
        }
        public void stop_plot()
        {
            shtead_control_flag = false;
        }
        public void Read()
        {
            while (shtead_control_flag)
            {
                try
                {
                    Thread.Sleep(50);
                    
                    string message = searial_read.ReadLine();
                    if(_continue)
                    {
                        BeginInvoke(new SetTextDeleg(si_DataReceived), new object[] { message });

                    }
                    if(enable_log ==1)
                    {
                        //if(File.Exists(textBox2.Text))
                        File.AppendAllText(textBox2.Text, message);
                    }
                    if(real_time_plot_count != 0)
                    {
                        for(int inx = 0; inx < real_time_plot_count;inx++)
                        {
                            arraygpplots[inx].realextract(message);
                        }
                        


                    }
                }
                catch (TimeoutException) { }
            }
        }

        public void call_plot(int plot_color, int plot_style, int plot_type, int xmessage, int ymessage, int back_color,int plot_axies,char SeperatedBy,string Header, int numberOfFields)
        {
            

            

            GraphPlot gp = new GraphPlot();
            arraygpplots[real_time_plot_count] = gp;
            arraygpplots[real_time_plot_count].Plot_axies_real = plot_axies;
            arraygpplots[real_time_plot_count].Style_real = plot_style;
            arraygpplots[real_time_plot_count].Color_real = plot_color;
            arraygpplots[real_time_plot_count].Back_color_real = back_color;
            arraygpplots[real_time_plot_count].Header_real = paras[xmessage] + " Vs " + paras[ymessage];
            arraygpplots[real_time_plot_count].Xmsg_real = xmessage;
            arraygpplots[real_time_plot_count].Ymsg_real = ymessage; 
            arraygpplots[real_time_plot_count].SeperatedBy_msg = SeperatedBy;
            arraygpplots[real_time_plot_count].Header_msg = Header;
            arraygpplots[real_time_plot_count].numberOfFields_msg = numberOfFields;
            

            gp.Show();
            real_time_plot_count++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //shtead_control_flag = false;
            button3.Enabled = true;
            _continue = false;
            textBox3.Visible = false;
            plotconnection_form.setmessage(this);
            plotconnection_form.Visible = true;

        }

        public void call_next_form(string var)
        {
            textBox3.Visible = true;
            glob_var = var;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            char seperatedBy =',';
            string header = "";
            int numberOfFields = 0;

            textBox3.Visible = false;
            plotconnection_form.Visible = false;
            if (glob_var == "Nmea")
            {
                seperatedBy = ',';
                header = "GGA";

                paras[0] = "Header";
                paras[1] = "Time";
                paras[2] = "Latitude";
                paras[3] = "N_S Indicator";
                paras[4] = "Logitude";
                paras[5] = "W_E Indicator";
                paras[6] = "Pos fix indicator";
                paras[7] = "Satelittes used";
                paras[8] = "HDOP";
                paras[9] = "MSL Altitude";
                paras[10] = "Units";
                paras[11] = "Geoid seperation";
                paras[12] = "Units";
                loop_numbr_max = 13;
            }
            else
            {
                loop_numbr_max = 0;

                string file_name = "C:\\BestExtractor\\" + glob_var;
                string[] read_msg_toextract = File.ReadAllLines(file_name);
                foreach (string var in read_msg_toextract)
                {
                    if (var.Contains("File_name:"))
                    {
                        continue;
                    }

                    if (var.Contains("Header:"))
                    {
                        header = var.Split(':')[1];
                        paras[loop_numbr_max] = "Header";
                        loop_numbr_max++;
                        continue;
                    }

                    if (var.Contains("seperated_by:"))
                    {
                        seperatedBy = Char.Parse(var.Split(':')[1]);
                        continue;
                    }

                    if (var.Contains("Number_of_fields:"))
                    {
                        numberOfFields = Int16.Parse(var.Split(':')[1]);
                        continue;
                    }
                    if (var.Contains("repetative:"))
                    {


                    }
                    if (var.Contains("field:"))
                    {
                        paras[loop_numbr_max] = var.Split(':')[1];
                        loop_numbr_max++;

                    }
                }
            }
            gpop_form.setformdata(this, paras, loop_numbr_max, seperatedBy, header,numberOfFields);
            gpop_form.Visible = true;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyData ==Keys.Enter)
            {
                pictureBox1_Click(sender, e);
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            GraphicsPath gp = new GraphicsPath();
            Point[] pt =
            {
                new Point(0,0),
                new Point(23,10),
                new Point(0,20),
                new Point(0,0)


            };
            gp.AddPolygon(pt);
            pictureBox1.Region = new Region(gp);

        }
    }
}
