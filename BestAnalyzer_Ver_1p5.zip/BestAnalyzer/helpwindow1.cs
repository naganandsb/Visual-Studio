﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class helpwindow1 : Form
    {
        public helpwindow1()
        {
            InitializeComponent();
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            Label lb = (Label)sender;
            lb.ForeColor = Color.BlueViolet;

        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            Label lb = (Label)sender;
            lb.ForeColor = Color.Crimson;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label7.Visible = true;
            label7.Text = label1.Text+"\n" + "\tThis is";
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label7.Visible = true;
            label7.Text = label2.Text + "\n" + "\t\t\tThis is option to user to analyse the realtime data";
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label7.Visible = true;
            label7.Text = label3.Text + "\n" + "\t\t\tThis is option to load a logged adata and analyse the same";
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label7.Visible = true;
            label7.Text = label4.Text + "\n" + "\t\t\tHere User can create his own message and then anayse using connection or stored data";
        }

        

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label6.ForeColor = Color.DarkGreen;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://mail.google.com/mail/u/0/#inbox?compose=DmwnWrRsppqbtWCsFQFLCZtVfMmMqlzmdXRwTmDRwKkbqBwDsmhPCdcDXgRthjPFsJCgwKxhHRtq");
            }
            catch(Exception)
            {
                System.Diagnostics.Process.Start("google.com");
            }
        }
    }
}
