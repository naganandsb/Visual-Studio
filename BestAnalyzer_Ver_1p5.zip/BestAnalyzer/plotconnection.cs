﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class plotconnection : Form
    {
        connections2 connect_2form;
        public plotconnection()
        {
            InitializeComponent();
        }

        public void setmessage(connections2 connection_2_form)
        {

            connect_2form = connection_2_form;
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Nmea");
            if (Directory.Exists("C:\\BestExtractor"))
            {
                string[] message_file_names = Directory.GetFiles("C:\\BestExtractor");
                foreach (string each in message_file_names)
                {
                    string fl_name = Path.GetFileName(each);
                    comboBox1.Items.Add(fl_name);
                }
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            connect_2form.call_next_form(comboBox1.Text);
        }
    }
}
