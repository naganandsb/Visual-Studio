﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestAnalyzer
{
    class startstop: Button
    {
        protected override void OnPaint(PaintEventArgs pevent)
        {
            GraphicsPath gp = new GraphicsPath(FillMode.Winding);
            GraphicsPath gp1 = new GraphicsPath(FillMode.Winding);

            gp.AddEllipse(5,5,ClientRectangle.Width-10,ClientRectangle.Height-10);

            gp1.AddEllipse(15, 15, ClientRectangle.Width - 20, ClientRectangle.Height - 20);

            Pen pen1 = new Pen(Color.Black,3);

            pevent.Graphics.DrawPath(pen1, gp);

            pevent.Graphics.DrawPath(pen1,gp1);

            this.Region = new System.Drawing.Region(gp);
            base.OnPaint(pevent);
        }
        

    }
}
