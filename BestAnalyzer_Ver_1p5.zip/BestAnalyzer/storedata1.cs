﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI.DataVisualization.Charting;
using System.Windows.Forms;

namespace BestAnalyzer
{
    public partial class storedata1 : Form
    {
        graphoption graphoption1 = new graphoption();
        bool bool_thread_control = false;
        int delay;
        Int64 Extracted_line_cnt = 0;
        int cnt_inshowtxt;
        string header_to_search = "";
        int loop_numbr_max = 0;
        bool enable_header = false;
        bool count_enable = false;
        public string[] paras_to_plot = new string[25];
        public string Header ="";
        public char SeperatedBy;
        public int numberOfFields = 0;
        public string[,] extracted_msg ;
        public string[] message_file_names;
        public string File_name = "";
        public string[] lines;

        private delegate void SetTextDeleg(string text);
        public storedata1()
        {
            InitializeComponent();

            graphoption1.TopLevel = false;
            panel3.Controls.Add(graphoption1);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File_name = openFileDialog1.FileName;

                textBox1.Text = File_name;

                lines = System.IO.File.ReadAllLines(File_name);

                

            }
        }

        private void si_DataReceived(string data)
        {
            textBox2.Text += data.Trim() + "\r\n"; textBox2.SelectionStart = textBox2.TextLength;
            textBox2.ScrollToCaret();
        }
        private void _show_data()
        {
            int cnt_local = 0;
            
            
            
            try
            {

                foreach (string each_line in lines)
                {
                    Thread.Sleep(100);
                    if(each_line.Contains(header_to_search) && enable_header)
                    {
                        
                        Thread.Sleep(delay);
                        cnt_local++;
                    }
                     
                    this.BeginInvoke(new SetTextDeleg(si_DataReceived), new object[] { each_line });
                    if (cnt_local == cnt_inshowtxt && count_enable)
                    {
                        break; 
                    }
                    if(bool_thread_control == false)
                    {
                        break;
                    }
                }

                
            }
            catch (Exception)
            {
                textBox2.Text = "File not selected or Empty file selected";
            }
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            label2.Visible = false;
            comboBox1.Visible = false;
            button4.Visible = false;

            textBox2.Visible = true;
            graphoption1.Visible = false;

            textBox3.Location = new System.Drawing.Point(549, 68);
            textBox4.Location = new System.Drawing.Point(549, 90);
            textBox5.Location = new System.Drawing.Point(549, 112);

            label3.Location = new System.Drawing.Point(382, 68);
            label4.Location = new System.Drawing.Point(382, 90);
            label5.Location = new System.Drawing.Point(382, 112);

            button5.Location = new System.Drawing.Point(550, 134);

            panel2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;

            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;

            button5.Visible = true;





        }

        private void storedata1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool_thread_control = false;
            button3.Enabled = true;
            panel2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;

            button5.Visible = false;

            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;

            panel2.Visible = true;
            label2.Visible = true;
            comboBox1.Items.Clear();
            comboBox1.Items.Add("NMEA");
            if (Directory.Exists("C:\\BestExtractor"))
            {
                message_file_names = Directory.GetFiles("C:\\BestExtractor");
                foreach(string each in message_file_names)
                {
                    string fl_name = Path.GetFileName(each);
                    comboBox1.Items.Add(fl_name);
                }
            }
            comboBox1.Visible = true;
            button4.Visible = true;

        }

        public void _ReadMessage()
        {
            Int64 line_cnt = 0;
            Int64 inner_loop_cnt = 0;
            
            try
            {

                foreach (string each_line in lines)
                {
                    inner_loop_cnt = 0;
                    if (!each_line.Contains(Header))
                    {
                        continue;
                    }
                    string[] sp_each_line = each_line.Split(SeperatedBy);

                    foreach(string element in sp_each_line)
                    {
                        extracted_msg[line_cnt, inner_loop_cnt] = element;

                        
                        inner_loop_cnt++;
                        if(numberOfFields == inner_loop_cnt)
                        {
                            break;
                        }
                    }

                    line_cnt++;

                }

                Extracted_line_cnt = line_cnt;
            }
            catch (Exception)
            {
                textBox2.Text = "File not selected or Empty file selected";
            }

            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            label2.Visible = false;
            comboBox1.Visible = false;
            button4.Visible = false;
            if(comboBox1.SelectedIndex == 0)
            {
                textBox2.Text = "NMEA MEssage Selected\n";
                Header = "GGA";
                SeperatedBy = ',';
                numberOfFields = 25;
                extracted_msg = new string[lines.Length, numberOfFields];
                paras_to_plot[0] = "Header";
                paras_to_plot[1] = "Time";
                paras_to_plot[2] = "Latitude";
                paras_to_plot[3] = "N_S Indicator";
                paras_to_plot[4] = "Logitude";
                paras_to_plot[5] = "W_E Indicator";
                paras_to_plot[6] = "Pos fix indicator";
                paras_to_plot[7] = "Satelittes used";
                paras_to_plot[8] = "HDOP";
                paras_to_plot[9] = "MSL Altitude";
                paras_to_plot[10] = "Units";
                paras_to_plot[11] = "Geoid seperation";
                paras_to_plot[12] = "Units";

                loop_numbr_max = 13;


                _ReadMessage();
                
            }
            else
            {
                loop_numbr_max = 0;
                
                string file_name = "C:\\BestExtractor\\"+comboBox1.Text;
                string[] read_msg_toextract = File.ReadAllLines(file_name);
                foreach(string var in read_msg_toextract)
                {
                    if(var.Contains("File_name:"))
                    {
                        continue;
                    }
                    
                    if (var.Contains("Header:"))
                    {
                        Header = var.Split(':')[1];
                        paras_to_plot[loop_numbr_max] = "Header";
                        loop_numbr_max++;
                        continue;
                    }
                
                    if (var.Contains("seperated_by:"))
                    {
                        SeperatedBy = Char.Parse(var.Split(':')[1]);
                        continue;
                    }
                
                    if (var.Contains("Number_of_fields:"))
                    {
                        numberOfFields = Int16.Parse(var.Split(':')[1]);
                        continue;
                    }
                    if (var.Contains("repetative:"))
                    {
                        
                        
                    }
                    if (var.Contains("field:"))
                    {
                        paras_to_plot[loop_numbr_max] = var.Split(':')[1];
                        loop_numbr_max++;

                    }
                }
                extracted_msg = new string[lines.Length, numberOfFields];
                _ReadMessage();
            }
        }
        public void call_plot(int plot_color, int plot_style, int plot_type, int xmessage, int ymessage,int back_color,int plot_axies)
        {
            float[] lat = new float[Extracted_line_cnt];
            float[] longi = new float[Extracted_line_cnt];


            for (Int64 i = 0; i < Extracted_line_cnt; i++)
            {
                try
                {

                    lat[i] = float.Parse(extracted_msg[i, xmessage]);

                    longi[i] = float.Parse(extracted_msg[i, ymessage]);



                }
                catch (Exception)
                {

                    continue;
                }

            }

            GraphPlot gp = new GraphPlot();

            gp.updateplot(paras_to_plot[xmessage] +" Vs "+ paras_to_plot[ymessage], lat, longi, Extracted_line_cnt, plot_style,plot_type,plot_color, back_color, plot_axies);
            //gp.updateplot(extracted_msg[10,xmessage] +" Vs "+ extracted_msg[10,ymessage], lat, longi, Extracted_line_cnt, plot_style,plot_type,plot_color, back_color, plot_axies);

            gp.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            graphoption1.setformdata(this,paras_to_plot, loop_numbr_max);
            graphoption1.Show();

            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            header_to_search = "";
            int cnt;
            try
            {
                delay = Int32.Parse(textBox3.Text);
            }
            catch(Exception)
            {
                 delay = 1;
            }
            try
            {
                cnt = Int32.Parse(textBox5.Text);
            }
            catch(Exception)
            {
                cnt = 0;
            }

            header_to_search = textBox4.Text;

            panel2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;

            bool_thread_control = true;

            button5.Visible = false;

            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            cnt_inshowtxt = cnt;


            if (cnt != 0)
            {
                count_enable = true;
            }
            if (header_to_search != "")
            {
                enable_header = true;
            }
            Thread rd_thread = new Thread(_show_data);
            rd_thread.IsBackground = true;
            rd_thread.Start();


        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(File.Exists(textBox1.Text))
            {
                 File_name = textBox1.Text;

                lines = System.IO.File.ReadAllLines(File_name);
            }
            
        }
    }
}
