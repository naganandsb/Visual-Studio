﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComReader
{
    public partial class Form1 : Form
    {
        SerialPort searial_read;
        private bool flag = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;
        public Form1()
        {
            InitializeComponent();

            comboBox1.Items.Clear();
            string[] portnames = SerialPort.GetPortNames();
            foreach (string port in portnames)
            {
                comboBox1.Items.Add(port);
            }
        }

        private void closebt_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            flag = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (flag)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            flag = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            


        }
        public bool running = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if(running == false)
            {
                Threading_fun();
                button1.Text = "Stop";
                running = true;
            }
            else
            {
                button1.Text = "Start";
                running = false;
            }
        }

        private void Threading_fun()
        {
            // read_comp_port();   

          //  Thread comportthread = new Thread(read_comp_port);   //cross thread error

                
            Thread comportthread = new Thread(() =>
            this.BeginInvoke((Action)delegate()
            {
                read_comp_port();

            }));
                

            comportthread.Start();
        }

        private void read_comp_port()
        {
            if(textBox2.Text == "")
            {
                return;
            }
            try
            {

                int badrt = Int32.Parse(textBox2.Text);
                string comport = comboBox1.Text;

                searial_read = new SerialPort(comport, badrt);
                searial_read.Open();


               // while(running)
                for (int lins = 0; lins < 100; lins++)
                {
                     
                    textBox1.Text += searial_read.ReadLine() + "\r\n";
                    textBox1.SelectionStart = textBox1.TextLength;
                    textBox1.ScrollToCaret();

                }

                searial_read.Close();
            }
            catch (Exception error)
            {
                 MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] portnames = SerialPort.GetPortNames();
            foreach (string port in portnames)
            {
                comboBox1.Items.Add(port);
            }
        }
    }
}
